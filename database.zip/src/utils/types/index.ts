export interface ActionState {
  message: string;
  status?: "idle" | "loading" | "success" | "error";
  errors?: { [key: string]: string } | {};
}
