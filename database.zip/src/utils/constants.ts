export const DEFAULT_LIMIT = 10;
export const MAX_LIMIT = 100;
export const DEFAULT_PAGE = 1;
