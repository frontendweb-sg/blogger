import { ZodError, ZodIssue } from "zod";

export function zodError(errors: ZodIssue[]) {
  return errors.reduce(
    (prev, error: ZodIssue) =>
      Object.assign(prev, {
        [error.path.join(".")]: error.message,
      }),
    {}
  );
}
