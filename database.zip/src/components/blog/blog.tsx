export function Blog() {
  return <div>Blog</div>;
}
