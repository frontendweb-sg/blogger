import type { IconNode } from "lucide-react";
import { Icon } from "lucide-react";

type InputProps = React.InputHTMLAttributes<HTMLInputElement> & {
  label?: string;
  startIcon?: IconNode;
  endIcon?: IconNode;
  error?: string;
  inline?: boolean;
};
export default function Input({
  label,
  startIcon,
  endIcon,
  error,
  inline,
  className,
  ...rest
}: InputProps) {
  return (
    <div>
      {label && <label>{label}</label>}
      <div>
        {startIcon && <Icon iconNode={startIcon} />}
        <input className="outline-none text-slate-900" {...rest} />
        {endIcon && <Icon iconNode={endIcon} />}
      </div>
      {error && <div>{error}</div>}
    </div>
  );
}
