"use client";

import Form from "../ui/form";
import Input from "../ui/input";
import { login } from "@/app/(auth)/action";

import { useActionState } from "react";
import SubmitButton from "../ui/submit-button";
import Link from "next/link";
import { ActionState } from "@/utils/types";

export default function LoginForm() {
  const [state, formAction, pending] = useActionState<ActionState>(login, {
    message: "Login successful!",
  });

  console.log(state);

  return (
    <Form
      action={formAction}
      className="w-full max-w-sm text-white  p-6 shadow-md rounded-lg"
    >
      <div>
        <h1>Login</h1>
        <p>
          If you don't have an account, please click{" "}
          <Link href="/login">login</Link>
        </p>
      </div>
      <Input
        error={state.errors?.email}
        name="email"
        type="email"
        label="Email"
      />
      <Input
        error={state.errors?.password}
        name="password"
        type="password"
        label="Password"
      />
      <SubmitButton>Login</SubmitButton>
    </Form>
  );
}
