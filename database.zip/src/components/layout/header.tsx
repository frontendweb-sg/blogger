import Container from "../ui/container";
import { ThemeButton } from "../ui/theme-button";
import Logo from "./logo";

export default function Header() {
  return (
    <header className="w-full">
      <Container className="flex items-center justify-between h-16">
        <Logo />
        <div className="flex items-center justify-end">
          <nav className="hidden space-x-4 sm:flex">
            <a href="/" className="text-black dark:text-white">
              Home
            </a>
            <a href="/about" className="text-black dark:text-white">
              About
            </a>
            <a href="/blog" className="text-black dark:text-white">
              Blog
            </a>
            <ThemeButton />
          </nav>
        </div>
      </Container>
    </header>
  );
}
