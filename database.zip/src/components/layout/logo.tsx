import { roboto } from "@/font/font";
import clsx from "clsx";

export default function Logo() {
  return (
    <div
      className={clsx(
        "flex items-center space-x-2  py-4  text-black dark:text-white font-black",
        roboto.variable
      )}
    >
      <span className="text-xl block font-bold">Blogger</span>
    </div>
  );
}
