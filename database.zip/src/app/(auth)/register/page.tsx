export default function Page() {
  return (
    <div>
      <h1>Register</h1>
    </div>
  );
}
