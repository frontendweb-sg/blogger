import { signIn } from "@/auth";
import { zodError } from "@/lib/zod-error";
import { ActionState } from "@/utils/types";

import { z } from "zod";

const loginSchema = z.object({
  email: z.string().nonempty("Email is required!").email("Invalid email"),
  password: z.string().min(8),
});

export const login = async (state: ActionState, formData: FormData) => {
  const body = Object.fromEntries(formData); // body is an object

  let prev = { ...state };
  const parse = loginSchema.safeParse(body);
  if (!parse.success) {
    return {
      ...prev,
      errors: zodError(parse.error.errors),
    };
  }

  console.log(parse.data, body);
  await signIn("credentials", {
    ...parse.data,
    // redirectTo: "/",
  });

  return prev;
};
