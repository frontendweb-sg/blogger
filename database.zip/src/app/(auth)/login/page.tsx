import LoginForm from "@/components/auth/login-form";
import Cover from "@/components/ui/cover";

export default function Page() {
  return (
    <Cover>
      <LoginForm />
    </Cover>
  );
}
